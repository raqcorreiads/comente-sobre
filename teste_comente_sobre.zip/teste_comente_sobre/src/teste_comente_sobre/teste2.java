package teste_comente_sobre;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class teste2 {

	@Test
	 void testPesquisar() {
        CommentController controller = new CommentController();
        Model model = new Model() {
            // Implementa��o vazia apenas para o teste
        };

        String result = controller.pesquisar(model);

        assertEquals("pesquisar", result);
        assertNull(model.getAttribute("topico"));
    }

    @Test
    void testRedirecionar() {
        CommentController controller = new CommentController();
        String topico = "Teste T�pico";

        String result = controller.redirecionar(topico);

        assertEquals("redirect:/comente-sobre/Teste%20T%C3%B3pico", result);
    }

    @Test
    void testRemoveAccents() {
        CommentController controller = new CommentController();
        String input = "��������";
        String expected = "aeiouca";

        String result = controller.removeAccents(input);

        assertEquals(expected, result);
    }


}
