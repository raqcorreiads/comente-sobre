import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ComentarioTest {

    @Test
    public void testSetAndGetMethods() {
        // Cria��o de um objeto Comentario para teste
        Comentario comentario = new Comentario();

        // Defini��o dos valores de teste
        Long id = 1L;
        String email = "test@example.com";
        String comentarioText = "This is a test comment";
        String topico = "Test Topic";

        // Teste dos m�todos de configura��o e obten��o
        comentario.setId(id);
        comentario.setEmail(email);
        comentario.setComentario(comentarioText);
        comentario.setTopico(topico);

        assertEquals(id, comentario.getId());
        assertEquals(email, comentario.getEmail());
        assertEquals(comentarioText, comentario.getComentario());
        assertEquals(topico, comentario.getTopico());
    }
}
